import Uploadcourses from '@/app/_Components/Uploadcourses'
import React from 'react'

const page = () => {
  return (
      <>
      <Uploadcourses/>
      </>
  )
}

export default page