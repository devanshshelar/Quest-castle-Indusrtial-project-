import Uploadpage from '@/app/_Components/Uploadpage'
import React from 'react'

const page = () => {
  return (
      <>
      <Uploadpage/>
      </>
  )
}

export default page