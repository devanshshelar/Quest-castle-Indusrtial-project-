import Editpage from '@/app/_Components/Editpage'
import React from 'react'

const page = () => {
  return (
      <>
      <Editpage/>
      </>
  )
}

export default page